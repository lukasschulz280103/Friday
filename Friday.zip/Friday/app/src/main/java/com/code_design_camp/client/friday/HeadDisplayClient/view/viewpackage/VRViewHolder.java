package com.code_design_camp.client.friday.HeadDisplayClient.view.viewpackage;

import android.provider.ContactsContract;
import android.view.View;

import java.util.ArrayList;

public class VRViewHolder {
    private ArrayList<View> mViewList= new ArrayList<>();
}
